<?php include 'db.php'; 
if (!isset($_GET['id'])) { header('Location: index.php'); exit; }
$id = intval($_GET['id']);
$res = mysqli_query($conn, "SELECT b.*, m.name AS maid_name FROM bookings b JOIN maid m ON b.maid_id = m.id WHERE b.id = $id");
if (!$res || mysqli_num_rows($res)==0) { echo 'Booking not found'; exit; }
$b = mysqli_fetch_assoc($res);
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Booking Success</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
  <div class="alert alert-success">
    <h4>Booking Submitted</h4>
    <p>Thank you, <?php echo htmlspecialchars($b['customer_name']); ?>. Your booking is pending approval.</p>
  </div>
  <h5>Booking Details</h5>
  <ul>
    <li>Maid: <?php echo htmlspecialchars($b['maid_name']); ?></li>
    <li>Date: <?php echo htmlspecialchars($b['date_scheduled']); ?></li>
    <li>Time: <?php echo htmlspecialchars($b['time_scheduled']); ?></li>
    <li>Status: <?php echo htmlspecialchars($b['status']); ?></li>
  </ul>
  <a href="index.php" class="btn btn-primary">Back to Home</a>
</div>
</body>
</html>
