# Maid Hiring Website - Mini Project (PHP + MySQL)

## What this is
A simple, college mini-project Maid Hiring Website built with:
- PHP (procedural, mysqli)
- MySQL
- Bootstrap 5 (CDN)
- Designed to run on XAMPP / LAMP

## How to run
1. Copy the `maid_hiring_website` folder into your XAMPP `htdocs` folder (or use the included zip).
2. Start Apache and MySQL in XAMPP.
3. Import `db.sql` into phpMyAdmin or run it in MySQL:
   - Database name: `maid_hiring`
4. Open in browser: `http://localhost/maid_hiring_website/index.php`
5. Admin panel:
   - `http://localhost/maid_hiring_website/admin/login.php`
   - default admin: username: `admin` password: `admin123`

## What's included
- Frontend pages: index.php, maids.php, hire.php, booking-success.php
- Admin panel: login, dashboard, add/manage maids, manage bookings
- db.php: database connection
- assets: simple CSS and placeholder images
- db.sql: create tables + sample data

This is a *minimal* project for demonstration and grading. Improve validation, security, and file handling for production use.
