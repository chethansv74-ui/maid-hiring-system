<?php
include 'db.php';
$maid = null;
if (!isset($_GET['id'])) {
    header('Location: maids.php'); exit;
}
$id = intval($_GET['id']);
$res = mysqli_query($conn, "SELECT * FROM maid WHERE id = $id");
if ($res && mysqli_num_rows($res) == 1) {
    $maid = mysqli_fetch_assoc($res);
} else {
    header('Location: maids.php'); exit;
}

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $customer_name = mysqli_real_escape_string($conn, $_POST['customer_name']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $date = mysqli_real_escape_string($conn, $_POST['date']);
    $time = mysqli_real_escape_string($conn, $_POST['time']);
    if (!$customer_name || !$phone || !$address || !$date || !$time) {
        $errors[] = 'All fields are required.';
    } else {
        $sql = "INSERT INTO bookings (customer_name, phone, address, maid_id, date_scheduled, time_scheduled, status)
                VALUES ('$customer_name','$phone','$address', $id, '$date', '$time', 'Pending')";
        if (mysqli_query($conn, $sql)) {
            $booking_id = mysqli_insert_id($conn);
            header('Location: booking-success.php?id=' . $booking_id); exit;
        } else {
            $errors[] = 'Database error: ' . mysqli_error($conn);
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Hire <?php echo htmlspecialchars($maid['name']); ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
  <a href="maids.php" class="btn btn-sm btn-secondary mb-3">← Back to Maids</a>
  <div class="row">
    <div class="col-md-6">
      <img src="assets/images/<?php echo htmlspecialchars($maid['image']); ?>" style="width:100%;height:320px;object-fit:cover">
      <h3 class="mt-2"><?php echo htmlspecialchars($maid['name']); ?></h3>
      <p>Experience: <?php echo htmlspecialchars($maid['experience']); ?> yrs</p>
      <p>Skills: <?php echo htmlspecialchars($maid['skills']); ?></p>
      <p>Price: ₹<?php echo htmlspecialchars($maid['price']); ?>/day</p>
    </div>
    <div class="col-md-6">
      <h4>Booking Form</h4>
      <?php if ($errors) {
        foreach ($errors as $e) echo '<div class="alert alert-danger">'.htmlspecialchars($e).'</div>';
      } ?>
      <form method="post">
        <div class="mb-2"><label>Name</label><input name="customer_name" class="form-control"></div>
        <div class="mb-2"><label>Phone</label><input name="phone" class="form-control"></div>
        <div class="mb-2"><label>Address</label><textarea name="address" class="form-control"></textarea></div>
        <div class="mb-2"><label>Date</label><input type="date" name="date" class="form-control"></div>
        <div class="mb-2"><label>Time</label><input type="time" name="time" class="form-control"></div>
        <button class="btn btn-primary">Confirm Booking</button>
      </form>
    </div>
  </div>
</div>
</body>
</html>
