-- SQL for Maid Hiring mini project
CREATE DATABASE IF NOT EXISTS maid_hiring DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE maid_hiring;

CREATE TABLE IF NOT EXISTS admin (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS maid (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(200),
  age INT,
  skills VARCHAR(500),
  experience INT,
  location VARCHAR(200),
  price DECIMAL(10,2),
  image VARCHAR(255),
  status VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS bookings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  customer_name VARCHAR(200),
  phone VARCHAR(50),
  address TEXT,
  maid_id INT,
  date_scheduled DATE,
  time_scheduled TIME,
  status VARCHAR(50) DEFAULT 'Pending',
  FOREIGN KEY (maid_id) REFERENCES maid(id) ON DELETE SET NULL
);

-- Insert default admin (username: admin, password: admin123)
INSERT INTO admin (username, password) VALUES
('admin', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9');

-- Sample maids
INSERT INTO maid (name, age, skills, experience, location, price, image, status) VALUES
('Lakshmi', 35, 'Cleaning, Cooking', 5, 'Mangalore', 400.00, 'maid1.jpg', 'Active'),
('Sita', 30, 'Baby Care, Cleaning', 4, 'Mangalore', 450.00, 'maid2.jpg', 'Active'),
('Radha', 28, 'Cooking, Laundry', 6, 'Mangalore', 500.00, 'maid3.jpg', 'Active');
