<?php include 'db.php'; ?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Maid Hiring - Home</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light mb-4">
  <div class="container">
    <a class="navbar-brand" href="index.php">MaidHire</a>
    <div>
      <a class="btn btn-outline-primary" href="maids.php">View Maids</a>
      <a class="btn btn-outline-secondary" href="admin/login.php">Admin</a>
    </div>
  </div>
</nav>

<div class="container">
  <div class="jumbotron p-4 bg-white rounded shadow-sm">
    <h1>Simple Maid Hiring Website</h1>
    <p class="lead">College mini-project. Hire verified maids for cleaning, cooking, baby care and elder care.</p>
    <hr>
    <a class="btn btn-primary" href="maids.php">Find Maids</a>
  </div>

  <h3 class="mt-4">Featured Maids</h3>
  <div class="row">
<?php
$q = mysqli_query($conn, "SELECT * FROM maid LIMIT 6");
while ($r = mysqli_fetch_assoc($q)) {
    echo '<div class="col-md-4 mb-3">
      <div class="card">
        <img src="assets/images/'.htmlspecialchars($r['image']).'" class="card-img-top" style="height:200px;object-fit:cover">
        <div class="card-body">
          <h5 class="card-title">'.htmlspecialchars($r['name']).'</h5>
          <p class="card-text">Experience: '.htmlspecialchars($r['experience']).' yrs<br>Skills: '.htmlspecialchars($r['skills']).'</p>
          <a href="hire.php?id='.intval($r['id']).'" class="btn btn-sm btn-success">Hire Now - ₹'.htmlspecialchars($r['price']).'/day</a>
        </div>
      </div>
    </div>';
}
?>
  </div>
</div>

</body>
</html>
