<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'maid_hiring';

$conn = mysqli_connect($host, $user, $pass, $dbname);
if (!$conn) {
    die('Database connection error: ' . mysqli_connect_error());
}
?>
