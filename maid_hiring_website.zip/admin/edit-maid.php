<?php
session_start();
if (!isset($_SESSION['admin_logged'])) { header('Location: login.php'); exit; }
include '../db.php';
if (!isset($_GET['id'])) { header('Location: manage-maids.php'); exit; }
$id = intval($_GET['id']);
$res = mysqli_query($conn, "SELECT * FROM maid WHERE id = $id");
if (!$res || mysqli_num_rows($res)==0) { header('Location: manage-maids.php'); exit; }
$m = mysqli_fetch_assoc($res);
$err='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $age = intval($_POST['age']);
    $skills = mysqli_real_escape_string($conn, $_POST['skills']);
    $experience = intval($_POST['experience']);
    $location = mysqli_real_escape_string($conn, $_POST['location']);
    $price = floatval($_POST['price']);
    $image = $m['image'];
    if (!empty($_FILES['image']['name'])) {
        $tmp = $_FILES['image']['tmp_name'];
        $orig = basename($_FILES['image']['name']);
        $target = '../assets/images/' . $orig;
        if (move_uploaded_file($tmp, $target)) {
            $image = $orig;
        }
    }
    $sql = "UPDATE maid SET name='$name', age=$age, skills='$skills', experience=$experience, location='$location', price=$price, image='$image' WHERE id=$id";
    if (mysqli_query($conn, $sql)) {
        header('Location: manage-maids.php'); exit;
    } else {
        $err = mysqli_error($conn);
    }
}
?>
<!doctype html><html><head><title>Edit Maid</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head><body>
<div class="container mt-4">
  <h3>Edit Maid</h3>
  <?php if ($err) echo '<div class="alert alert-danger">'.htmlspecialchars($err).'</div>'; ?>
  <form method="post" enctype="multipart/form-data">
    <div class="mb-2"><input name="name" class="form-control" value="<?php echo htmlspecialchars($m['name']); ?>"></div>
    <div class="mb-2"><input name="age" class="form-control" value="<?php echo htmlspecialchars($m['age']); ?>"></div>
    <div class="mb-2"><input name="skills" class="form-control" value="<?php echo htmlspecialchars($m['skills']); ?>"></div>
    <div class="mb-2"><input name="experience" class="form-control" value="<?php echo htmlspecialchars($m['experience']); ?>"></div>
    <div class="mb-2"><input name="location" class="form-control" value="<?php echo htmlspecialchars($m['location']); ?>"></div>
    <div class="mb-2"><input name="price" class="form-control" value="<?php echo htmlspecialchars($m['price']); ?>"></div>
    <div class="mb-2">Current Image:<br><img src="../assets/images/<?php echo htmlspecialchars($m['image']); ?>" style="height:120px"></div>
    <div class="mb-2"><input type="file" name="image" class="form-control"></div>
    <button class="btn btn-success">Update Maid</button>
  </form>
</div>
</body></html>
