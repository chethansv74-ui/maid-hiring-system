<?php
session_start();
if (!isset($_SESSION['admin_logged'])) { header('Location: login.php'); exit; }
include '../db.php';
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    mysqli_query($conn, "DELETE FROM maid WHERE id = $id");
    header('Location: manage-maids.php'); exit;
}
$maids = mysqli_query($conn, "SELECT * FROM maid");
?>
<!doctype html><html><head><title>Manage Maids</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head><body>
<div class="container mt-4">
  <h3>Manage Maids</h3>
  <a href="add-maid.php" class="btn btn-primary mb-2">Add Maid</a>
  <table class="table table-bordered">
    <tr><th>ID</th><th>Name</th><th>Location</th><th>Price</th><th>Action</th></tr>
    <?php while($m = mysqli_fetch_assoc($maids)) {
      echo '<tr><td>'.$m['id'].'</td><td>'.htmlspecialchars($m['name']).'</td><td>'.htmlspecialchars($m['location']).'</td><td>₹'.htmlspecialchars($m['price']).'</td><td>
        <a class="btn btn-sm btn-warning" href="edit-maid.php?id='.$m['id'].'">Edit</a>
        <a class="btn btn-sm btn-danger" href="?delete='.$m['id'].'" onclick="return confirm(\'Delete?\')">Delete</a>
      </td></tr>';
    } ?>
  </table>
</div>
</body></html>
