<?php
session_start();
if (!isset($_SESSION['admin_logged'])) { header('Location: login.php'); exit; }
include '../db.php';
if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    if ($_GET['action'] === 'approve') {
        mysqli_query($conn, "UPDATE bookings SET status='Approved' WHERE id=$id");
    } elseif ($_GET['action'] === 'reject') {
        mysqli_query($conn, "UPDATE bookings SET status='Rejected' WHERE id=$id");
    }
    header('Location: manage-bookings.php'); exit;
}
$bs = mysqli_query($conn, "SELECT b.*, m.name AS maid_name FROM bookings b JOIN maid m ON b.maid_id = m.id ORDER BY b.id DESC");
?>
<!doctype html><html><head><title>Manage Bookings</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head><body>
<div class="container mt-4">
  <h3>Manage Bookings</h3>
  <table class="table table-bordered">
    <tr><th>ID</th><th>Customer</th><th>Maid</th><th>Date</th><th>Time</th><th>Status</th><th>Action</th></tr>
    <?php while($b = mysqli_fetch_assoc($bs)) {
      echo '<tr><td>'.$b['id'].'</td><td>'.htmlspecialchars($b['customer_name']).' ('.htmlspecialchars($b['phone']).')</td><td>'.htmlspecialchars($b['maid_name']).'</td><td>'.htmlspecialchars($b['date_scheduled']).'</td><td>'.htmlspecialchars($b['time_scheduled']).'</td><td>'.htmlspecialchars($b['status']).'</td><td>
        <a class="btn btn-sm btn-success" href="?action=approve&id='.$b['id'].'">Approve</a>
        <a class="btn btn-sm btn-danger" href="?action=reject&id='.$b['id'].'">Reject</a>
      </td></tr>';
    } ?>
  </table>
</div>
</body></html>
