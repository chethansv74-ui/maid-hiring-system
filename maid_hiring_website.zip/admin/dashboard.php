<?php
session_start();
if (!isset($_SESSION['admin_logged'])) { header('Location: login.php'); exit; }
include '../db.php';
$total_maids = mysqli_fetch_assoc(mysqli_query($conn,'SELECT COUNT(*) AS c FROM maid'))['c'];
$total_bookings = mysqli_fetch_assoc(mysqli_query($conn,'SELECT COUNT(*) AS c FROM bookings'))['c'];
$pending = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) AS c FROM bookings WHERE status='Pending'"))['c'];
?>
<!doctype html>
<html><head>
<title>Admin Dashboard</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head><body>
<div class="container mt-4">
  <div class="d-flex justify-content-between">
    <h3>Dashboard</h3>
    <a href="manage-maids.php" class="btn btn-sm btn-secondary">Manage Maids</a>
  </div>
  <div class="row mt-3">
    <div class="col-md-4"><div class="card p-3">Total Maids: <strong><?php echo $total_maids; ?></strong></div></div>
    <div class="col-md-4"><div class="card p-3">Total Bookings: <strong><?php echo $total_bookings; ?></strong></div></div>
    <div class="col-md-4"><div class="card p-3">Pending: <strong><?php echo $pending; ?></strong></div></div>
  </div>
  <div class="mt-4">
    <a class="btn btn-primary" href="add-maid.php">Add Maid</a>
    <a class="btn btn-warning" href="manage-bookings.php">Manage Bookings</a>
  </div>
</div>
</body></html>
