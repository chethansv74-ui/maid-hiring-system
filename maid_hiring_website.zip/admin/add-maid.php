<?php
session_start();
if (!isset($_SESSION['admin_logged'])) { header('Location: login.php'); exit; }
include '../db.php';
$err='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $age = intval($_POST['age']);
    $skills = mysqli_real_escape_string($conn, $_POST['skills']);
    $experience = intval($_POST['experience']);
    $location = mysqli_real_escape_string($conn, $_POST['location']);
    $price = floatval($_POST['price']);
    // image upload (simple)
    $image = 'placeholder.jpg';
    if (!empty($_FILES['image']['name'])) {
        $tmp = $_FILES['image']['tmp_name'];
        $orig = basename($_FILES['image']['name']);
        $target = '../assets/images/' . $orig;
        if (move_uploaded_file($tmp, $target)) {
            $image = $orig;
        }
    }
    $sql = "INSERT INTO maid (name, age, skills, experience, location, price, image, status)
            VALUES ('$name',$age,'$skills',$experience,'$location',$price,'$image','Active')";
    if (mysqli_query($conn, $sql)) {
        header('Location: manage-maids.php'); exit;
    } else {
        $err = mysqli_error($conn);
    }
}
?>
<!doctype html><html><head><title>Add Maid</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head><body>
<div class="container mt-4">
  <h3>Add Maid</h3>
  <?php if ($err) echo '<div class="alert alert-danger">'.htmlspecialchars($err).'</div>'; ?>
  <form method="post" enctype="multipart/form-data">
    <div class="mb-2"><input name="name" class="form-control" placeholder="Name"></div>
    <div class="mb-2"><input name="age" class="form-control" placeholder="Age" type="number"></div>
    <div class="mb-2"><input name="skills" class="form-control" placeholder="Skills (comma separated)"></div>
    <div class="mb-2"><input name="experience" class="form-control" placeholder="Experience (years)" type="number"></div>
    <div class="mb-2"><input name="location" class="form-control" placeholder="Location"></div>
    <div class="mb-2"><input name="price" class="form-control" placeholder="Price per day"></div>
    <div class="mb-2"><input type="file" name="image" class="form-control"></div>
    <button class="btn btn-success">Add Maid</button>
  </form>
</div>
</body></html>
