<?php
session_start();
include '../db.php';
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $u = mysqli_real_escape_string($conn, $_POST['username']);
    $p = mysqli_real_escape_string($conn, $_POST['password']);
    $res = mysqli_query($conn, "SELECT * FROM admin WHERE username = '$u'");
    if ($res && mysqli_num_rows($res)==1) {
        $row = mysqli_fetch_assoc($res);
        if (password_verify($p, $row['password']) || hash('sha256', $p) === $row['password']) {
            $_SESSION['admin_logged'] = true;
            header('Location: dashboard.php'); exit;
        }
    }
    $msg = 'Invalid credentials';
}
?>
<!doctype html>
<html><head>
<title>Admin Login</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head><body>
<div class="container mt-5">
  <div class="col-md-4 offset-md-4">
    <h3>Admin Login</h3>
    <?php if ($msg) echo '<div class="alert alert-danger">'.htmlspecialchars($msg).'</div>'; ?>
    <form method="post">
      <div class="mb-2"><input name="username" class="form-control" placeholder="Username"></div>
      <div class="mb-2"><input type="password" name="password" class="form-control" placeholder="Password"></div>
      <button class="btn btn-primary">Login</button>
    </form>
  </div>
</div>
</body></html>
